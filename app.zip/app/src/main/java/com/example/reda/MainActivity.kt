package com.example.reda

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.content.Intent
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        @SuppressLint("WrongViewCast")
        val btn = findViewById<Button>(R.id.button)
        val TVinfo = findViewById<TextView>(R.id.tv)
        var count = 3
        btn.setOnClickListener {
            if(name.text.toString() == "Admin" && password.text.toString() == "Admin"){
                val intent = Intent(this, WelcomeActivity::class.java)
                startActivity(intent)
            } else {
                if((--count) == 0){
                    btn.isEnabled = false
                }
                name.getText().clear()
                password.getText().clear()
                TVinfo.text = "Number of attempts : "+count

            }
        }
    }
}