package com.example.reda

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class WelcomeActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        val reda = findViewById<EditText>(R.id.reda)
        val ib = findViewById<Button>(R.id.ib)
        val id = findViewById<TextView>(R.id.ad)
        ib.setOnClickListener {
            if(reda.text.toString() == "Reda"){
                id.text = "That's all for today"
            }
        }

    }
}